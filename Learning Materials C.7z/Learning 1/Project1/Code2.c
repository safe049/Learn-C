#include<stdio.h>

void main()
{
	// Welcome to chapter2 �� Converts.
	int int1 = 3; // define int1 and giving a value 3.
	float float1 = 3.14; //define float1
	printf("int1 = %d , float1 = %f", int1, float1); // Let's review last chapter.
	int list[5] = { 1,2,3,4,5 };
	printf("choosed number %d,second number %d", list[2], list[0]);
}
