#include<stdio.h>

void main()
{
	// chapter 5:Include[input and output]
	int a = 6;
	printf("output-%d\n", a);
	// output a int:6
	// how to let we manually input a value? like,a user inputing his pwd or sth?
	// scanf is sth you like!
	scanf_s("%d", &a); // let ourself input one! You can also use scanf,but scanf_s is safer.
	printf("output-%d\n", a);
	// if you input 100,it output 100,which makes a's value 100!
	// polite one:
	printf("Please input a int:");
	scanf_s("%d", &a); 
	printf("output-%d\n", a);
	// float
	float b = 3.14;
	printf("Please input a float:");
	scanf_s("%f", &b);
	printf("output-%f\n", b);
    // char
	char c = 'k';
	getchar(); // filter the enter key and blank,which avoid after entering float then pressing enter,but program skip the input progress which think enter is a char.
	printf("Please input a char:");
	scanf_s("%c", &c);
	printf("output-%c\n", c);
	// better way that inputting char
	char d = 'a';
	d = getchar();
	putchar(d);
	// define a char var,then use getchar() to let user input,after that putchar(var); will give the char to var as a value,then print it out.
	// THIS ONLY WORK SINGLE.
	// see you next chapter.
}