#include<stdio.h>

void main()
{
	// This chapter we will try to solve some question.
	// Q1: INPUT A CAPS CHAR,THEN OUTPUT IT BY lowercase
	/*char c = 'a';*/
	/*printf("c = %c\nc = %d\n", c,c);*/ // output c by char type and int type.
	// you can see int c output 97,which is ascii of char c.
/*	char d = 65;*/ // if you want it ASCII,dont use ''
	/*printf("d = %c\nd = %d\n", d, d);*/
	// you can see it output char as A,int as 65, in ASCII code,65 stands for A,A stands for 65
	// CAPS and lowercase has a 32 value minus.
	// so A is 65,then 'a' is 65+32.

	// NOW LETS TRY SOLVE THE PROBLEM.
	// 1. input
	// 2. throught ascii to make it lowercase
	// 3. output
	char ch = 'a';
	printf("Please input a caps char:");
	ch = getchar();
	ch = ch + 32; // plus 32,make it ascii lowercase
	printf("The lowercase is ");
	putchar(ch);
	// THERE IS A INVINSIBLE CONVERT WHICH CONVERT CHAR INTO A INT,THEN USE PUTCHAR TO OUTPUT IT,BECAUSE YOU CANNOT USE A CHAR TO PLUS SO IT STRAIGHT CONVERTED IT.
	// C class ends,hope you learned it.
}