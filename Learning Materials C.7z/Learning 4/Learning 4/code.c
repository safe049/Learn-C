#include<stdio.h>

void main()
{
	// Welcome! to chapter4:Logical Operators
	int a = 100;
	a = 5 > 3;
	// 1 stands for true , and 0 stands for false
	// lets see is 5 really > 3?
	printf("a's logical operators is %d\n", a); // As you can see,5 did > 3. because it shows 1 which means true.
	// what about 5<3?
	a = 5 < 3;
	printf("a's logical operators is %d\n", a); // As you can see,5 dont < 3 , because it shows 0 which means false.
	// lets see did a = b? a=5*8 and b equals 40
	a = 5 * 8;
	int b = 40;
	printf("did a equals b? %d\n", a == b); // it shows 1,yes 5*8 is 40,and 40 = 40.thats true.
	// var1 == var2 means to judge is these vars equals each other?
	// This is sth advanced. &&:It means logical and, that is, and. 
	// When the result of the expression on both sides of the operator is true, the entire result is true, otherwise, as long as one side is false, the result is false.
	// a || c means a or c.anyone of the var is true,then result is true.
	// !c means non c.
	a = 0; // a is false
	int c = 1; // c is true
	printf("and cac is %d,or cac is %d,non cac is %d\n", a && c, a || c, !c);
	// non cac means if c is true,then !c is false,if c is false,then !c is true.
	// Of the above three logical operators, the logical non - !'s has the highest priority, followed by logical &&&, logical or ||  Lowest priority
	// non experiment:
	c = 1; // c is true
	printf("non cac of c is %d\n", !c);
	c = 0; // c is false
	printf("non cac of c is %d\n", !c);
	// Lets have some experiment
	// and
	// any var is false,then its all false.
	int x = 1; //true
	int y = 0; //false
	printf("and cac of x and y is %d\n", x && y);
	x = 1;
	y = 1;
	printf("and cac of x and y is %d\n", x && y);
	// or
	// any var is true then its all true,no matter another is false.
	x = 1;
	y = 0;
	printf("or cac of x and y is %d\n", x || y);
	x = 0;
	y = 0;
	printf("or cac of x and y is %d\n", x || y);
	// non
	// opposite of true and false results.
	y = 1;
	printf("non cac of y is %d\n", !y);
	y = 0;
	printf("non cac of y is %d\n", !y);
	// Very good,see you next file.
}